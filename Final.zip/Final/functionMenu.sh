lpy ()
{
	cat "menuLPY.txt"
	printf "\n----	Insert option : "
	read op
	com="pydf"
	case $op in
		--help ) less "helpLPY.txt";;
		*"-v"* | *"--version"* ) com+=" $op";;
		*"-a"* | *"--all"* ) com+=" $op";;
		*"-h"* | *"--human-readable"* ) com+=" $op";;
		*"-H"* | *"--si"* ) com+=" $op";;
		*"--block-size"* ) com+=" $op";;
		*"-k"* | *"--kilobytes"* ) com+=" $op";;
		*"-i"* | *"--inodes"* ) com+=" $op";;
		*"-l"* | *"--local"* ) com+=" $op";;
		*"-m"* | *"--megabytes"* ) com+=" $op";;
		*"-g"* | *"--gigabytes"* ) com+=" $op";;
		*"--blocks"* ) com+=" $op";;
		*"--bw"* ) com+=" $op";;
		--mounts ) com+=" $op";;
		*"-B"* | *"--show-binds"* ) com+=" $op";;
		*) echo "-lpy format not respected or command is invalid"
	esac
	$com
}

ldk ()
{
	cat "menuLDK.txt"
	printf "\n----	Insert option : "
	read op
	com="sudo fdisk"
	case $op in
		-h | --help ) less "helpLDK.txt";;
		*"-v"* | *"--version"* ) com+=" $op";;
		*"-b"* | *"--sector-size"* ) com+=" $op";;
		*"-c"* | *"--compatibility"* ) com+=" $op";;
		*"-L"* | *"--color"* ) com+=" $op";;
		*"-l"* | *"--list"* ) com+=" $op";;
		*"-o"* | *"--output"* ) com+=" $op";;
		*"-t"* | *"--type"* ) com+=" $op";;
		*"-u"* | *"--units"* ) com+=" $op";;
		*"-s"* | *"--getsz"* ) com+=" $op";;
		*"-w"* | *"--wipe"* ) com+=" $op";;
		*"-W"* | *"--wipe-partitions"* ) com+=" $op";;
		*"-C"* | *"--cylinders"* ) com+=" $op";;
		*"-H"* | *"--heads"* ) com+=" $op";;
		*"-S"* | *"--sectors"* ) com+=" $op";;
		*"--bytes"* ) com+=" $op";;
		*"/"*) com+=" $op";;
		*) echo "-ldk format not respected or command is invalid"
	esac
	$com
}
