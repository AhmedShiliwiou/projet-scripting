#!/bin/bash
source function.sh

case $1 in
	*"-LPY"* | *"-lpy"* ) lpy $@ ;;
	*"-LDK"* | *"-ldk"* ) ldk $@ ;;
	-PLOT | -plot ) ./courbe.sh ;;
	"-h" | "-H" ) less "helpme.txt" ;;
	*) echo "-- Invalid command --"
	   echo "You can ask for help by tapping -h or -H"
esac

