#!/bin/bash

lpy ()
{
	#echo $#
	if [[ $# > 1 ]];then
		com="pydf"
		for i in "${@:2}";do
			#echo $i
			case $i in
				--help ) less "helpLPY.txt";;
				*"-v"* | *"--version"* ) com+=" $i";;
				*"-a"* | *"--all"* ) com+=" $i";;
				*"-h"* | *"--human-readable"* ) com+=" $i";;
				*"-H"* | *"--si"* ) com+=" $i";;
				*"--block-size"* ) com+=" $i";;
				*"-k"* | *"--kilobytes"* ) com+=" $i";;
				*"-i"* | *"--inodes"* ) com+=" $i";;
				*"-l"* | *"--local"* ) com+=" $i";;
				*"-m"* | *"--megabytes"* ) com+=" $i";;
				*"-g"* | *"--gigabytes"* ) com+=" $i";;
				*"--blocks"* ) com+=" $i";;
				*"--bw"* ) com+=" $i";;
				--mounts ) com+=" $i";;
				*"-B"* | *"--show-binds"* ) com+=" $i";;
				*) echo "-lpy format not respected or command is invalid"
			esac
		done
		$com
	else pydf
	fi
}

ldk ()
{
	#echo $#
	if [[ $# > 1 ]];then
		com="sudo fdisk"
		for i in "${@:2}";do
			#echo $i
			case $i in
				-h | --help ) less "helpLDK.txt";;
				*"-v"* | *"--version"* ) com+=" $i";;
				*"-b"* | *"--sector-size"* ) com+=" $i";;
				*"-c"* | *"--compatibility"* ) com+=" $i";;
				*"-L"* | *"--color"* ) com+=" $i";;
				*"-l"* | *"--list"* ) com+=" $i";;
				*"-o"* | *"--output"* ) com+=" $i";;
				*"-t"* | *"--type"* ) com+=" $i";;
				*"-u"* | *"--units"* ) com+=" $i";;
				*"-s"* | *"--getsz"* ) com+=" $i";;
				*"-w"* | *"--wipe"* ) com+=" $i";;
				*"-W"* | *"--wipe-partitions"* ) com+=" $i";;
				*"-C"* | *"--cylinders"* ) com+=" $i";;
				*"-H"* | *"--heads"* ) com+=" $i";;
				*"-S"* | *"--sectors"* ) com+=" $i";;
				*"--bytes"* ) com+=" $i";;
				*"/"*) com+=" $i";;
				*) echo "-ldk format not respected or command is invalid"
			esac
		done
		$com
	else echo "-ldk format not respected or command is invalid"
	fi
}

