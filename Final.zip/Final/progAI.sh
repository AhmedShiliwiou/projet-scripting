#!/bin/bash
source functionINTERFACE.sh


yad --form --width=600 --height=50 --text="Choose :" \
--button="-lpy":1 \
--button="-ldk":2 \
--button="plot":3 \
--button="help":4 \
--button="manuel":5 \
--button=gtk-quit:6


choix=$?
echo "choix = $choix"

[[ $choix -eq 6 ]] && exit 0

if [[ $choix -eq 1 ]]; then clear &&
	lpy && ./progAI.sh
elif [[ $?choix -eq 2 ]]; then clear &&
	ldk && ./progAI.sh
elif [[ $choix -eq 3 ]]; then clear &&
	./courbe.sh && ./progAI.sh
elif [[ $choix -eq 4 ]]; then clear &&
	less "helpme.txt" && ./progAI.sh
elif [[ $choix -eq 5 ]]; then clear &&
	manuel && ./progAI.sh
fi


