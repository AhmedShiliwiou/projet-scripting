#! /bin/bash

if [[ $# -le 0 ]] ;then
	./progAI.sh
else
	if [[ $1 == "m" || $1 == "M" ]] ;then
		./progM.sh
	else 
		./progSI.sh $@
	fi
fi
