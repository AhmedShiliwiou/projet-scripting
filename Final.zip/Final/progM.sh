#!/bin/bash
source "functionMenu.sh"

echo "*) lpy	:	displays the amount of disk space available"
echo "*) ldk	:	creation and manipulation of partition tables"
echo "*) plot	:	courbes des informations les plus pertinentes"
echo "*) h	:	help"
printf "\n----	Insert command : "
read rep

case $rep in
	LPY | lpy ) lpy ;;
	LDK | ldk ) ldk ;;
	plot | PLOT ) ./courbe.sh ;;
	"h" | "H" ) less "helpme.txt" ;;
	*) echo "-- Invalid command --"
	   echo "You can ask for help by tapping -h or -H"
esac

