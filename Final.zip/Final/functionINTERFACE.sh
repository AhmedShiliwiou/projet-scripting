#!/bin/bash

lpy ()
{
	op=$(zenity --entry --title="-LPY options" --text="Ajouter une option (optionnel)")

	if [ $? == 1 ] ;then exit;pydf
	else
		#local com
		com="pydf"
			case $op in
				--help ) less "helpLPY.txt";;
				*"-v"* | *"--version"* ) com+=" $op";;
				*"-a"* | *"--all"* ) com+=" $op";;
				*"-h"* | *"--human-readable"* ) com+=" $op";;
				*"-H"* | *"--si"* ) com+=" $op";;
				*"--block-size"* ) com+=" $op";;
				*"-k"* | *"--kilobytes"* ) com+=" $op";;
				*"-i"* | *"--inodes"* ) com+=" $op";;
				*"-l"* | *"--local"* ) com+=" $op";;
				*"-m"* | *"--megabytes"* ) com+=" $op";;
				*"-g"* | *"--gigabytes"* ) com+=" $op";;
				*"--blocks"* ) com+=" $op";;
				*"--bw"* ) com+=" $op";;
				--mounts ) com+=" $op";;
				*"-B"* | *"--show-binds"* ) com+=" $op";;
				*) echo "-lpy format not respected or command is invalid"
			esac
		$com
		#cat `$com` | cut -f2 -d" " > t.txt
		$com | zenity --text-info --title="Disks Amount" --width="1000" --height="600"
		#echo $dir
		#$com | head -n 12 | tail -n 5 | awk '{ prnint $11 }' | nl > a.txt
		#gnuplot -p -e "plot 'a.txt' with linespoints  linestyle 1"
	fi
}

ldk ()
{
	op=$(zenity --entry --title="-LDK options" --text="Ajouter une option (obligatoire)")
	if [ $? == 1 ] ;then exit;echo "-ldk format not respected or command is invalid"
	else
		com="sudo fdisk"
			case $op in
				-h | --help ) less "helpLDK.txt";;
				*"-v"* | *"--version"* ) com+=" $op";;
				*"-b"* | *"--sector-size"* ) com+=" $op";;
				*"-c"* | *"--compatibility"* ) com+=" $op";;
				*"-L"* | *"--color"* ) com+=" $op";;
				*"-l"* | *"--list"* ) com+=" $op";;
				*"-o"* | *"--output"* ) com+=" $op";;
				*"-t"* | *"--type"* ) com+=" $op";;
				*"-u"* | *"--units"* ) com+=" $op";;
				*"-s"* | *"--getsz"* ) com+=" $op";;
				*"-w"* | *"--wipe"* ) com+=" $op";;
				*"-W"* | *"--wipe-partitions"* ) com+=" $op";;
				*"-C"* | *"--cylinders"* ) com+=" $op";;
				*"-H"* | *"--heads"* ) com+=" $op";;
				*"-S"* | *"--sectors"* ) com+=" $op";;
				*"--bytes"* ) com+=" $op";;
				*"/"*) com+=" $op";;
				*) echo "-ldk format not respected or command is invalid"
			esac
		$com
		$com | zenity --text-info --title="Disks" --width="1000" --height="600"
	fi
}

manuel ()
{
	commandee=$(zenity --entry --text="Entrez votre commande principale" )
	if [ $? == 1 ] ;then exit ;fi
	case $commandee in
		*"-LPY"* | *"-lpy"* ) lpy ;;
		*"-LDK"* | *"-ldk"* ) ldk ;;
		-PLOT | -plot ) ./courbe.sh ;;
		-h" | "-H" ) less "helpme.txt" ;;
		*) echo "-- Invalid command --"
		   echo "You can ask for help by tapping -h or -H"
	esac
}

